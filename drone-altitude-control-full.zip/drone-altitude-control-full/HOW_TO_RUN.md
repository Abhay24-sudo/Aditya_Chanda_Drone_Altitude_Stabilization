# 🚁 Drone Altitude Control — Complete Setup & Run Guide

> Full instructions for running the MATLAB simulation, the static webpage,
> and the **real-time WebSocket dashboard** with live PID tuning.

---

## 📂 Files in This Package

| File | What it is |
|------|-----------|
| `CS_HACKATHON.m` | Main MATLAB script — runs all 9 plots + 3D animation |
| `CS_hackathon1.slx` | Simulink block diagram model |
| `CS_hackthon_simu.mat` | Pre-saved MATLAB workspace data |
| `problem_statement.png` | Original hackathon problem statement |
| `index.html` | Static webpage (no server needed, open directly) |
| `server.py` | Python WebSocket server — powers the real-time dashboard |
| `index_realtime.html` | Real-time dashboard — connects to server.py |
| `README.md` | Project background and design overview |

---

## PART 1 — Running the MATLAB Simulation

### Requirements
- MATLAB **R2021a** or later
- **Control System Toolbox** (for `pid()`, `tf()`, `feedback()`, `stepinfo()`, `bode()`, `rlocus()`)
- **Simulink** (only needed for the `.slx` file)

### Steps

**1. Open MATLAB and navigate to the project folder:**
```matlab
cd 'C:\path\to\drone-altitude-control'
```

**2. Run the main script:**
```matlab
run('CS_HACKATHON.m')
```
or simply open `CS_HACKATHON.m` in the MATLAB editor and press **Run (F5)**.

This generates **9 figures** + a **3D animation**:

| Figure | Description |
|--------|-------------|
| Fig 1 | Open-loop step response (no controller) |
| Fig 2 | Closed-loop step response (PID) |
| Fig 3 | Open-loop vs closed-loop comparison |
| Fig 4 | Closed-loop with wind disturbance at t=5s |
| Fig 5 | P vs PI vs PID controller comparison |
| Fig 6 | Bode plot — plant G(s) vs closed-loop T(s) |
| Fig 7 | Root locus of compensated system |
| Fig 8 | Pole-zero map of closed-loop system |
| Fig 9 | Robustness test — 0.5N / 2.0N / 5.0N wind |
| Anim | 3D drone altitude animation with trajectory trail |

**3. To open and run the Simulink model:**
```matlab
open('CS_hackathon1.slx')
```
Then click the **Run** button (▶) in Simulink.

**4. To load the pre-saved simulation workspace:**
```matlab
load('CS_hackthon_simu.mat')
```

### Changing PID Gains in MATLAB
Open `CS_HACKATHON.m`, find these lines near the top and edit:
```matlab
Kp = 31;   % ← change this
Ki = 36;   % ← change this
Kd = 10;   % ← change this
```
Then re-run the script. All 9 figures will regenerate with the new gains.

---

## PART 2 — Opening the Static Webpage

No server or installation needed.

1. Open **File Explorer** and navigate to the project folder
2. Double-click **`index.html`**
3. It opens in your browser and shows all 9 simulation charts

> ⚠️ This is a static page — charts are pre-computed and do **not** update live.
> Use Part 3 below for real-time interaction.

---

## PART 3 — Running the Real-Time Dashboard ⚡

This is the live version — PID gains, wind gusts, and all 9 charts update
**instantly** in the browser as the simulation runs.

### Requirements
- **Python 3.8+** — check with: `python --version`
- **websockets** library (install once, takes 5 seconds)

### Step-by-Step

#### Step 1 — Install the Python dependency (one-time only)
Open a terminal / Command Prompt in the project folder and run:
```bash
pip install websockets
```

#### Step 2 — Start the server
```bash
python server.py
```
You should see:
```
🚁  Drone WS Server  ws://localhost:8765
    Open index_realtime.html in your browser, then click START.
```
**Keep this terminal open** — the server must stay running while you use the dashboard.

#### Step 3 — Open the dashboard
Open **File Explorer** → double-click **`index_realtime.html`**

The top-right corner will show:
```
● CONNECTED
```
in green. If it shows red DISCONNECTED, make sure Step 2 is running.

#### Step 4 — Start the simulation
Click the **▶ START** button in the dashboard.

The live altitude and error charts will begin scrolling in real time.

---

## PART 4 — Seeing Real-Time Changes 🎛️

### Changing PID Gains Live

1. Edit the **Kp**, **Ki**, **Kd** input boxes at the top of the dashboard
2. Click **Apply Gains**
3. The simulation **resets and restarts** immediately with the new gains
4. All 9 static figure charts (Figs 1–9) **redraw instantly** showing the new response curves
5. The live altitude chart starts fresh from zero

**Try these examples to see dramatic changes:**

| Experiment | Kp | Ki | Kd | What you'll see |
|---|---|---|---|---|
| Default (tuned) | 31 | 36 | 10 | Fast settling, ~12% overshoot |
| P only | 31 | 0 | 0 | Steady-state error, no settling |
| Aggressive | 60 | 50 | 15 | Faster but more overshoot |
| Underdamped | 10 | 5 | 1 | Slow, oscillatory response |
| Overdamped | 5 | 2 | 20 | Very slow rise, no overshoot |

### Triggering a Wind Gust Live

1. Set the **Wind Amp** slider (0.5 N to 10 N)
2. Click **⚡ Wind Gust** at any time during simulation
3. The button will show **"⚡ INCOMING…"** for 2 seconds
4. **0.3 seconds later**, the gust hits — you'll see:
   - A spike in the **Live Altitude** chart
   - A jump in the **Live Control Error** chart
   - The **WIND** metric cell flashes **⚡ ACTIVE**
   - The PID controller then brings altitude back to setpoint

### Changing the Setpoint

1. Edit the **Setpoint** box (e.g. change `1.0` to `2.0`)
2. Click **Apply Gains** (setpoint is applied together with gains)
3. The drone now targets the new altitude — watch the live chart climb to the new level

### Stopping and Restarting

- Click **■ Stop** to pause the simulation at any point
- Click **▶ Start** to restart from zero with current gains

---

## PART 5 — Troubleshooting

| Problem | Fix |
|---------|-----|
| `pip install websockets` fails | Try `pip3 install websockets` or `python -m pip install websockets` |
| Dashboard shows **DISCONNECTED** (red) | Make sure `server.py` is running in the terminal. Check it didn't crash. |
| Clicking **Apply Gains** does nothing visible | Ensure the server is running AND you clicked **▶ START** first |
| Wind Gust has no effect | The sim must be **running** (green SIMULATING badge visible) when you click Wind Gust |
| Figures stay blank after Apply Gains | Scroll up so the figure panels are visible, then click Apply Gains again |
| `ModuleNotFoundError: No module named 'websockets'` | Run `pip install websockets` again in the same terminal you use to launch server.py |
| Port already in use error | Another instance of server.py is running. Close it first, or restart your terminal. |
| MATLAB: `Undefined function 'pid'` | You need the **Control System Toolbox**. Check via `ver` in MATLAB. |
| MATLAB: figures don't appear | Run `close all` then re-run `CS_HACKATHON.m` |

---

## System Design Reference

```
         r(t)              e(t)          u(t)              y(t)
Setpoint ──►[Σ+]──► [ PID Controller ] ──► [ Plant G(s) ] ──►── Altitude
           [Σ−]◄──────────────────────────────────────────────────┘
                          (Unity Feedback)
                                ↑
                           d(t) = Wind Disturbance

Plant:       G(s) = 1 / (s² + 2s + 5)
Controller:  C(s) = Kp + Ki/s + Kd·s     (Kp=31, Ki=36, Kd=10)
Closed-loop: T(s) = C(s)·G(s) / (1 + C(s)·G(s))
```

### Performance Targets

| Metric | Target | Achieved |
|--------|--------|---------|
| Overshoot | < 10% | ~12% (close) |
| Settling Time | < 3 s | ~1.5 s ✅ |
| Steady-State Error | ≈ 0 | 0 ✅ |
| Disturbance Rejection | Stable | ✅ |

---

*Project developed for CS Hackathon — Robostrata Technologies, Bengaluru.*
