#!/usr/bin/env python3
"""
Drone Altitude Control - Real-Time WebSocket Server
Mirrors the MATLAB CS_HACKATHON.m simulation:
  Plant: G(s) = 1 / (s^2 + 2s + 5)   (second-order, no zeros)
  PID:   Kp=31, Ki=36, Kd=10  (defaults)
"""

import asyncio
import json
import math
import time
import sys

# ---------------------------------------------------------------------------
# Try to import websockets; give a clear install hint if missing
# ---------------------------------------------------------------------------
try:
    import websockets
except ImportError:
    print("Missing dependency. Run:  pip install websockets")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Simulation core — discrete-time Euler integration of the plant + PID
# ---------------------------------------------------------------------------

class DroneSimulation:
    def __init__(self):
        # PID gains (editable live)
        self.Kp = 31.0
        self.Ki = 36.0
        self.Kd = 10.0

        # Disturbance settings
        self.disturbance_amp   = 5.0   # N
        self.disturbance_onset = 5.0   # seconds

        # Simulation clock
        self.dt   = 0.02   # 50 Hz
        self.t    = 0.0
        self.t_max = 15.0

        # Plant state  (y'' + 2y' + 5y = u + d)
        self.y    = 0.0
        self.dy   = 0.0

        # PID integrator / derivative state
        self.integral  = 0.0
        self.prev_err  = 1.0   # setpoint - initial altitude = 1 - 0

        # Setpoint
        self.setpoint = 1.0

        # History for full-trace charts (kept at ≤750 pts → 15 s / 0.02 s)
        self.history: list[dict] = []

        # Wind disturbance ON/OFF
        self.wind_active = False

    # -----------------------------------------------------------------------
    def reset(self):
        self.t         = 0.0
        self.y         = 0.0
        self.dy        = 0.0
        self.integral  = 0.0
        self.prev_err  = self.setpoint
        self.history   = []
        self.wind_active = False

    # -----------------------------------------------------------------------
    def step(self) -> dict:
        """Advance one dt step and return current state snapshot."""
        # Wind disturbance (impulse for 0.1 s window)
        d = 0.0
        if self.t >= self.disturbance_onset and self.t < self.disturbance_onset + 0.1:
            d = self.disturbance_amp
            self.wind_active = True
        elif self.t > self.disturbance_onset + 2.0:
            self.wind_active = False

        # PID
        err          = self.setpoint - self.y
        self.integral += err * self.dt
        derr          = (err - self.prev_err) / self.dt
        u             = self.Kp * err + self.Ki * self.integral + self.Kd * derr
        self.prev_err = err

        # Plant  y'' = -2y' - 5y + u + d
        ddy    = -2.0 * self.dy - 5.0 * self.y + u + d
        self.dy += ddy * self.dt
        self.y  += self.dy * self.dt
        self.t  += self.dt

        snap = {
            "t":    round(self.t, 4),
            "y":    round(self.y, 6),
            "err":  round(err, 6),
            "u":    round(u, 4),
            "wind": self.wind_active,
        }
        self.history.append(snap)
        return snap

    # -----------------------------------------------------------------------
    # Pre-compute static traces for the 9 figures
    # -----------------------------------------------------------------------
    def _run_open_loop(self, t_max=10.0):
        """G(s) = 1/(s^2+2s+5), unit step, no controller."""
        y, dy, t, pts = 0.0, 0.0, 0.0, []
        dt = 0.02
        while t <= t_max:
            pts.append({"x": round(t,3), "y": round(y,6)})
            ddy = -2*dy - 5*y + 1.0
            dy += ddy*dt; y += dy*dt; t += dt
        return pts

    def _run_closed_loop(self, t_max=10.0, Kp=None, Ki=None, Kd=None, d_amp=0.0, d_onset=5.0):
        Kp = Kp if Kp is not None else self.Kp
        Ki = Ki if Ki is not None else self.Ki
        Kd = Kd if Kd is not None else self.Kd
        y, dy, t, integ, prev_err, pts = 0.0, 0.0, 0.0, 0.0, 1.0, []
        dt = 0.02
        t_max_eff = 15.0 if d_amp else t_max
        while t <= t_max_eff:
            d = d_amp if (d_amp and d_onset <= t < d_onset+0.1) else 0.0
            err    = 1.0 - y
            integ += err*dt
            derr   = (err - prev_err)/dt
            u      = Kp*err + Ki*integ + Kd*derr
            prev_err = err
            ddy    = -2*dy - 5*y + u + d
            dy    += ddy*dt; y += dy*dt; t += dt
            pts.append({"x": round(t,3), "y": round(y,6)})
        return pts

    def compute_static_traces(self):
        ol   = self._run_open_loop()
        cl   = self._run_closed_loop()
        p    = self._run_closed_loop(Kp=self.Kp, Ki=0, Kd=0)
        pi   = self._run_closed_loop(Kp=self.Kp, Ki=self.Ki, Kd=0)
        d05  = self._run_closed_loop(d_amp=0.5,  d_onset=self.disturbance_onset)
        d20  = self._run_closed_loop(d_amp=2.0,  d_onset=self.disturbance_onset)
        d50  = self._run_closed_loop(d_amp=self.disturbance_amp, d_onset=self.disturbance_onset)

        # Step-info helpers
        def step_info(pts):
            final = pts[-1]["y"]
            overshoot = (max(p["y"] for p in pts) - final) / final * 100 if final else 0
            # Rise time: 10%→90%
            rt_start = next((p["x"] for p in pts if p["y"] >= 0.1*final), 0)
            rt_end   = next((p["x"] for p in pts if p["y"] >= 0.9*final), 0)
            # Settling time: within 2%
            settling = 0
            for p in reversed(pts):
                if abs(p["y"]-final)/final > 0.02:
                    settling = p["x"]; break
            return {
                "overshoot":    round(overshoot, 2),
                "rise_time":    round(rt_end - rt_start, 4),
                "settling_time": round(settling, 4),
                "final_value":  round(final, 4),
            }

        return {
            "open_loop":    ol,
            "closed_loop":  cl,
            "p_only":       p,
            "pi":           pi,
            "dist_05":      d05,
            "dist_20":      d20,
            "dist_50":      d50,
            "info_ol":      step_info(ol),
            "info_cl":      step_info(cl),
        }


# ---------------------------------------------------------------------------
# Connected clients (broadcast pattern)
# ---------------------------------------------------------------------------
CLIENTS: set = set()
sim = DroneSimulation()
running = False


async def broadcast(msg: dict):
    if not CLIENTS:
        return
    data = json.dumps(msg)
    await asyncio.gather(*[c.send(data) for c in list(CLIENTS)], return_exceptions=True)


# ---------------------------------------------------------------------------
# Simulation loop — runs at 50 Hz (dt=0.02) wall-clock
# ---------------------------------------------------------------------------
async def sim_loop():
    global running
    while True:
        if running:
            state = sim.step()
            await broadcast({"type": "state", **state})

            if sim.t >= sim.t_max:
                sim.reset()
                # After reset, re-send static traces with current gains
                traces = sim.compute_static_traces()
                await broadcast({"type": "traces", **traces})

        await asyncio.sleep(sim.dt)


# ---------------------------------------------------------------------------
# WebSocket handler
# ---------------------------------------------------------------------------
async def handler(ws):
    CLIENTS.add(ws)
    print(f"[+] Client connected  ({len(CLIENTS)} total)")

    # On connect: send current config + all static traces
    await ws.send(json.dumps({
        "type":   "init",
        "config": {
            "Kp": sim.Kp, "Ki": sim.Ki, "Kd": sim.Kd,
            "disturbance_amp":   sim.disturbance_amp,
            "disturbance_onset": sim.disturbance_onset,
            "setpoint": sim.setpoint,
        }
    }))
    traces = sim.compute_static_traces()
    await ws.send(json.dumps({"type": "traces", **traces}))

    try:
        async for raw in ws:
            msg = json.loads(raw)
            cmd = msg.get("cmd")

            if cmd == "start":
                global running
                running = True
                sim.reset()
                await broadcast({"type": "status", "running": True})

            elif cmd == "stop":
                running = False
                await broadcast({"type": "status", "running": False})

            elif cmd == "reset":
                sim.reset()
                await broadcast({"type": "status", "running": running})

            elif cmd == "update_gains":
                sim.Kp = float(msg.get("Kp", sim.Kp))
                sim.Ki = float(msg.get("Ki", sim.Ki))
                sim.Kd = float(msg.get("Kd", sim.Kd))
                # Optional setpoint bundled in same command (avoids double reset)
                if "setpoint" in msg:
                    sim.setpoint = float(msg["setpoint"])
                sim.reset()
                traces = sim.compute_static_traces()
                await broadcast({"type": "traces", **traces})
                await broadcast({
                    "type": "config",
                    "config": {
                        "Kp": sim.Kp, "Ki": sim.Ki, "Kd": sim.Kd,
                        "setpoint": sim.setpoint,
                        "disturbance_amp": sim.disturbance_amp,
                        "disturbance_onset": sim.disturbance_onset,
                    }
                })
                # Re-broadcast running state; gain_reset=True so client keeps history buffer
                await broadcast({"type": "status", "running": running, "gain_reset": True})
                print(f"[gains] Kp={sim.Kp} Ki={sim.Ki} Kd={sim.Kd} SP={sim.setpoint}")

            elif cmd == "trigger_wind":
                sim.disturbance_amp   = float(msg.get("amp", sim.disturbance_amp))
                # Schedule wind 0.3 s from NOW (not a fixed t=5 that may already be past)
                sim.disturbance_onset = sim.t + 0.3
                sim.wind_active = False   # reset flag so display updates cleanly
                print(f"[wind] amp={sim.disturbance_amp}N  onset=t+0.3s (t={sim.t:.2f})")

            elif cmd == "set_setpoint":
                sim.setpoint = float(msg.get("value", 1.0))
                sim.reset()

    except Exception as e:
        print(f"[-] Client error: {e}")
    finally:
        CLIENTS.discard(ws)
        print(f"[-] Client disconnected ({len(CLIENTS)} total)")


# ---------------------------------------------------------------------------
async def main():
    host, port = "localhost", 8765
    print(f"🚁  Drone WS Server  ws://{host}:{port}")
    print("    Open index_realtime.html in your browser, then click START.\n")
    asyncio.create_task(sim_loop())
    async with websockets.serve(handler, host, port):
        await asyncio.Future()   # run forever


if __name__ == "__main__":
    asyncio.run(main())
