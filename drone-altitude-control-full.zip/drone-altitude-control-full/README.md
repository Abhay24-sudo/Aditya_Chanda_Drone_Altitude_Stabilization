# 🚁 Drone Altitude Stabilization — PID Control System

> A MATLAB/Simulink project for designing and simulating a PID controller to regulate drone altitude under external wind disturbances.

---

## 📌 Problem Statement

Design a control system to regulate the altitude of a drone subjected to external disturbances such as wind.

The vertical dynamics of the drone are approximated by the second-order transfer function:

$$G(s) = \frac{1}{s^2 + 2s + 5}$$

| Signal | Description |
|--------|-------------|
| Input | Thrust command |
| Output | Altitude |
| Disturbance | External force acting at t = 5s |

---

## 🎯 Control Objectives

The designed controller must satisfy:

- ✅ Overshoot < **10%**
- ✅ Settling time < **3 seconds**
- ✅ Steady-state error ≈ **0**
- ✅ System remains **stable under disturbance**

---

## 🛠️ Tasks

1. Analyze open-loop response
2. Design a suitable PID controller
3. Simulate closed-loop response
4. Introduce disturbance and evaluate robustness

---

## 📂 Repository Structure

```
drone-altitude-control/
│
├── CS_HACKATHON.m          # Main MATLAB script (analysis + animation)
├── CS_hackathon1.slx       # Simulink model file
├── CS_hackthon_simu.mat    # Simulation data / workspace variables
├── problem_statement.png   # Original problem statement image
└── README.md               # This file
```

---

## ⚙️ PID Controller Parameters

| Parameter | Value |
|-----------|-------|
| Kp (Proportional) | 31 |
| Ki (Integral) | 36 |
| Kd (Derivative) | 10 |

The controller was tuned to meet all performance objectives while maintaining robustness against wind disturbances.

---

## 📊 Simulation Results

The MATLAB script (`CS_HACKATHON.m`) generates the following plots:

| Figure | Description |
|--------|-------------|
| Figure 1 | Open-loop step response (no controller) |
| Figure 2 | Closed-loop step response (PID controlled) |
| Figure 3 | Open-loop vs closed-loop comparison |
| Figure 4 | Closed-loop response with wind disturbance at t = 5s |
| Figure 5 | Controller comparison: P vs PI vs PID |
| Figure 6 | Bode plot (open-loop plant vs closed-loop) |
| Figure 7 | Root locus of compensated system |
| Figure 8 | Pole-zero map of closed-loop system |
| Figure 9 | Robustness test — multiple wind disturbance magnitudes |

A **3D drone altitude animation** is also generated, showing real-time altitude stabilization with trajectory trail.

---

## 📈 Performance Summary

| Metric | Open-Loop | PID Controlled |
|--------|-----------|----------------|
| Overshoot (%) | — | < 10% |
| Settling Time (s) | — | < 3 s |
| Rise Time (s) | — | Improved |
| Steady-State Error | Present | ≈ 0 |

---

## 🧪 Robustness Testing

Wind disturbance magnitudes tested:
- 🟢 Light Wind — 0.5 N
- 🔵 Strong Wind — 2.0 N
- 🔴 Severe Wind — 5.0 N

All scenarios demonstrate the PID controller's ability to reject disturbances and return to setpoint altitude.

---

## 🚀 How to Run

### Prerequisites
- MATLAB R2021a or later
- Control System Toolbox
- Simulink (for `.slx` model)

### Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/<your-username>/drone-altitude-control.git
   cd drone-altitude-control
   ```

2. Open MATLAB and navigate to the project folder.

3. Run the main script:
   ```matlab
   run('CS_HACKATHON.m')
   ```

4. To open the Simulink model:
   ```matlab
   open('CS_hackathon1.slx')
   ```

5. To load simulation workspace data:
   ```matlab
   load('CS_hackthon_simu.mat')
   ```

---

## 📐 System Design Overview

```
         r(t)          e(t)        u(t)              y(t)
Setpoint ──►[+]──► [ PID Controller ] ──► [ Plant G(s) ] ──►── Altitude
          ─[−]◄─────────────────────────────────────────────┘
                        (Unity Feedback)

                              ↑
                         d(t) = Wind Disturbance at t=5s
```

---

## 🏆 Deliverables

- [x] Transfer function model
- [x] Controller parameters (Kp, Ki, Kd)
- [x] Step response plots
- [x] Disturbance response analysis
- [x] Simulink model
- [x] 3D drone animation

---

## 📍 Event Details

**CS Hackathon** — Control Systems Design Challenge  
Organized by **Robostrata Technologies**  
📍 557, 9th Cross, Jayanagar 7th Block West, Bengaluru 560 070  
📞 +91 81979 45038 | ✉️ robostratatechnologies@gmail.com

---

## 📄 License

This project was developed as part of a hackathon challenge. Feel free to use and adapt for educational purposes.
