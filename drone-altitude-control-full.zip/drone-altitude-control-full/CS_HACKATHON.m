clear; clc; close all;

%% Plant
num = [1]; den = [1 2 5];
G = tf(num, den);

%% Figure 1 — Open-Loop
figure(1);
step(G, 10);
title('Open-Loop Step Response (No Controller)');
xlabel('Time (s)'); ylabel('Altitude'); grid on;
info_ol = stepinfo(G);
fprintf('\n--- Open-Loop ---\n');
fprintf('Overshoot:     %.2f%%\n', info_ol.Overshoot);
fprintf('Settling Time: %.4f s\n', info_ol.SettlingTime);
fprintf('Rise Time:     %.4f s\n', info_ol.RiseTime);

%% PID
Kp = 31; Ki = 36; Kd = 10;
C = pid(Kp, Ki, Kd);
T = feedback(C*G, 1);

%% Figure 2 — Closed-Loop
figure(2);
step(T, 10);
title('Closed-Loop Step Response (PID Controlled)');
xlabel('Time (s)'); ylabel('Altitude'); grid on;
info_cl = stepinfo(T);
fprintf('\n--- Closed-Loop PID ---\n');
fprintf('Overshoot:     %.2f%%\n', info_cl.Overshoot);
fprintf('Settling Time: %.4f s\n', info_cl.SettlingTime);
fprintf('Rise Time:     %.4f s\n', info_cl.RiseTime);

%% Figure 3 — Comparison
figure(3);
hold on;
[y_ol, t_ol] = step(G, 10);
[y_cl, t_cl] = step(T, 10);
plot(t_ol, y_ol, 'r--', 'LineWidth', 2);
plot(t_cl, y_cl, 'b-',  'LineWidth', 2);
yline(1, 'k:', 'LineWidth', 1.2);
legend('Open-Loop (No Controller)', 'Closed-Loop (PID)', 'Setpoint');
title('Open-Loop vs Closed-Loop Comparison');
xlabel('Time (s)'); ylabel('Altitude'); grid on;

%% Figure 4 — Disturbance at t=5s
t = 0:0.01:15;
r = ones(size(t));
d = zeros(size(t));
d(t >= 5) = 20;

T_ref  = feedback(C*G, 1);
T_dist = feedback(G, C);

[y_ref,  ~] = lsim(T_ref,  r, t);
[y_dist, ~] = lsim(T_dist, d, t);
y_total = y_ref + y_dist;

figure(4);
plot(t, y_total, 'b-', 'LineWidth', 2); hold on;
xline(5, 'r--', 'Wind Disturbance @ t=5s', 'LineWidth', 1.5);
yline(1, 'k:', 'Setpoint', 'LineWidth', 1.2);
title('Closed-Loop Response with Wind Disturbance at t=5s');
xlabel('Time (s)'); ylabel('Altitude');
legend('Altitude', 'Disturbance onset', 'Setpoint');
grid on;

%% ==========================================
% 3D DRONE ANIMATION
%% ==========================================

figure;

axis([-5 5 -5 5 0 2]);
grid on;
view(3);

xlabel('X');
ylabel('Y');
zlabel('Altitude');

title('3D Drone Altitude Control Animation');

hold on;

% Ground
[X,Y] = meshgrid(-5:1:5,-5:1:5);
Z = zeros(size(X));

surf(X,Y,Z,...
    'FaceColor',[0.7 0.7 0.7],...
    'FaceAlpha',0.5,...
    'EdgeColor','none');

% Drone body
h = plot3(0,0,y_total(1),...
    'ko',...
    'MarkerSize',20,...
    'MarkerFaceColor','b');

% Trajectory path
traj = animatedline('Color','r','LineWidth',2);

for k = 1:length(t)

    z = y_total(k);

    % Drone motion
    set(h,'XData',0,'YData',0,'ZData',z);

    % Trajectory trail
    addpoints(traj,0,0,z);

    % Disturbance text
    if t(k) >= 5 && t(k) <= 7
        title('Wind Disturbance Detected');
    else
        title('Drone Altitude Stabilization');
    end

    drawnow;

end







%% Figure 5 — P vs PI vs PID
C_P   = pid(Kp, 0,  0);
C_PI  = pid(Kp, Ki, 0);
C_PID = pid(Kp, Ki, Kd);

T_P   = feedback(C_P   * G, 1);
T_PI  = feedback(C_PI  * G, 1);
T_PID = feedback(C_PID * G, 1);

figure(5);
hold on;
[yP,   tP]   = step(T_P,   10);
[yPI,  tPI]  = step(T_PI,  10);
[yPID, tPID] = step(T_PID, 10);
plot(tP,   yP,   'g-',  'LineWidth', 2);
plot(tPI,  yPI,  'm--', 'LineWidth', 2);
plot(tPID, yPID, 'b-',  'LineWidth', 2);
yline(1, 'k:', 'Setpoint');
legend('P only', 'PI', 'PID');
title('Controller Comparison: P vs PI vs PID');
xlabel('Time (s)'); ylabel('Altitude'); grid on;

%% Figure 6 — Bode Plot
figure(6);
bode(G); hold on;
bode(T);
legend('Open-Loop Plant G(s)', 'Closed-Loop T(s)');
title('Bode Plot'); grid on;

%% Summary
fprintf('\n========== PERFORMANCE SUMMARY ==========\n');
fprintf('%-25s %-15s %-15s\n', 'Metric', 'Open-Loop', 'PID');
fprintf('%-25s %-15.2f %-15.2f\n', 'Overshoot (%)',     info_ol.Overshoot,    info_cl.Overshoot);
fprintf('%-25s %-15.4f %-15.4f\n', 'Settling Time (s)', info_ol.SettlingTime, info_cl.SettlingTime);
fprintf('%-25s %-15.4f %-15.4f\n', 'Rise Time (s)',     info_ol.RiseTime,     info_cl.RiseTime);
fprintf('=========================================\n');


%% Figure 7 — Root Locus
figure(7);
rlocus(C*G);
title('Root Locus of Compensated System (C*G)');
grid on;

%% Figure 8 — Pole-Zero Map
figure(8);
pzmap(T);
title('Pole-Zero Map of Closed-Loop System');
grid on;
sgrid;

%% Figure 9 — Robustness: Multiple Disturbance Magnitudes
figure(9);
hold on;
colors = {'r', 'b', 'g'};
amps = [0.5, 2.0, 5.0];
labels = {'Light Wind (0.5N)', 'Strong Wind (2.0N)', 'Severe Wind (5.0N)'};
for i = 1:3
    d = zeros(size(t));
    d(t >= 5) = amps(i);
    [y_dist, ~] = lsim(T_dist, d, t);
    y_total = y_ref + y_dist;
    plot(t, y_total, colors{i}, 'LineWidth', 2.5, 'DisplayName', labels{i});
end
h1 = yline(1, 'w:', 'LineWidth', 1.5);
h2 = xline(5, 'y--', 'LineWidth', 1.5);
h1.HandleVisibility = 'off';
h2.HandleVisibility = 'off';
title('Robustness Test: Multiple Wind Disturbance Magnitudes');
xlabel('Time (s)'); ylabel('Altitude');
legend show; grid on;uavScenarioDesigner